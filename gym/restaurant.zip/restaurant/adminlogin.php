
<html>
<head></head>
<body>
<form method = "post" action ="admin.php">
Admin<input type="text" name="user"><br>
Password<input type="password" name="pass"><br>
<button type="submit">Login
</button></form>
</body></html>